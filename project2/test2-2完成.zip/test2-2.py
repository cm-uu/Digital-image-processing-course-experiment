import cv2
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']
def spatial_enhancement_medical(image_path):

    pil_img = Image.open(image_path).convert('L')#转为灰度模式
    img1 = np.array(pil_img, dtype=np.float64)


    # 图B计算拉普拉斯边缘
    img2 = cv2.Laplacian(img1, cv2.CV_64F)
    #归一化
    img2 = 255 * (img2 - img2.min()) / (img2.max() - img2.min() + 1e-8)
    img2 = img2.astype(np.float64)

    # C=A+B
    img3 = img1 + img2

    img3 = 255 * (img3 - img3.min()) / (img3.max() - img3.min() + 1e-8)
    img3 = img3.astype(np.float64)


    sobel_x = cv2.Sobel(img1, cv2.CV_64F, dx=1, dy=0)
    sobel_y = cv2.Sobel(img1, cv2.CV_64F, dx=0, dy=1)  # y方向梯度
    img4 = cv2.magnitude(sobel_x, sobel_y)

    img4 = 255 * (img4 - img4.min()) / (img4.max() - img4.min() + 1e-8)
    img4 = img4.astype(np.float64)  # 图像D（Sobel梯度幅值）

    # 5. 中值滤波
    img5 = cv2.medianBlur(np.uint8(img4), ksize=5)
    img5 = img5.astype(np.float64)


    img6 = img3 * img5

    img6 = 255 * (img6 - img6.min()) / (img6.max() - img6.min() + 1e-8)
    img6 = img6.astype(np.float64)


    img7 = img1 + img6
    # 归一化到[0,255]
    img7 = 255 * (img7 - img7.min()) / (img7.max() - img7.min() + 1e-8)
    img7 = img7.astype(np.float64)  # 图像G（A+F结果）


    img8 = np.power(img7 / 255.0, 0.5)
    img8 = img8 * 255.0
    img8 = img8.astype(np.uint8)

    # 整理所有步骤结果（转为uint8方便显示和保存）
    results = {
        'A_原图': img1.astype(np.uint8),
        'B_Laplacian边缘': img2.astype(np.uint8),
        'C_A+B锐化': img3.astype(np.uint8),
        'D_Sobel梯度': img4.astype(np.uint8),
        'E_5x5中值滤波': img5.astype(np.uint8),
        'F_C*E乘法': img6.astype(np.uint8),
        'G_A+F加法': img7.astype(np.uint8),
        'H_幂率变换(γ=0.5)': img8
    }
    return results

def show_and_save_results(results, save_path_prefix="medical_enhancement_"):
    plt.figure(figsize=(16, 10))
    for i, (name, img) in enumerate(results.items(), 1):
        plt.subplot(2, 4, i)
        plt.imshow(img, cmap='gray')
        plt.title(name, fontsize=12)
        plt.axis('off')
    plt.tight_layout()
    plt.show()

    # 保存所有结果（便于对比报告）
    for name, img in results.items():
        save_name = save_path_prefix + name.replace(' ', '_').replace('(', '').replace(')', '').replace('*', '')
        cv2.imwrite(f"{save_name}.jpg", img)
    print("所有步骤结果已保存，前缀为：", save_path_prefix)

if __name__ == '__main__':

    image_path = r"object.png"
    try:
        # 执行空域增强
        enhancement_results = spatial_enhancement_medical(image_path)
        # 显示并保存结果
        show_and_save_results(enhancement_results)
        print("实验完成！所有步骤与报告一致，结果已保存和显示。")
    except Exception as e:
        print(f"出错：{e}")
        print("请检查：1. 图像路径是否正确；2. 图像是否为有效格式；3. 依赖库是否安装（opencv-python、pillow、matplotlib、numpy）")